var month ={
  1:"January",
  2:"February",
  3:"March",
  4:"April",
  5:"May",
  6:"June",
  7:"July",
  8:"August",
  9:"September",
  10:"October",
  11:"November",
  12:"December"
};

var month_no=[1,2,3,4,5,6,7,8,9,10,11,12];

function the_month(x){
  return month[x];
}

var get_month=document.getElementById("");
